package com.bitm.tourmate;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bitm.tourmate.Map.MapsActivity;

public class NearbyFragment extends Fragment {

    private ImageView policeIv, bankIv, atmIv, parkIv, mosqueIv, cafeIv, educationIv;


    public NearbyFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_nearby, container, false);

        init(view);

        policeIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), MapsActivity.class);
                intent.putExtra("search", "police");
                startActivity(intent);
            }
        });
        bankIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), MapsActivity.class);
                intent.putExtra("search", "bank");
                startActivity(intent);
            }
        });



        educationIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), MapsActivity.class);
                intent.putExtra("search", "university");
                startActivity(intent);
            }
        });

        cafeIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), MapsActivity.class);
                intent.putExtra("search", "cafe");
                startActivity(intent);
            }
        });



        mosqueIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), MapsActivity.class);
                intent.putExtra("search", "mosque");
                startActivity(intent);
            }
        });

        parkIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), MapsActivity.class);
                intent.putExtra("search", "park");
                startActivity(intent);
            }
        });

        atmIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), MapsActivity.class);
                intent.putExtra("search", "atm");
                startActivity(intent);
            }
        });

        return view;
    }

    private void init(View view) {

        policeIv = view.findViewById(R.id.pliceIv);
        bankIv = view.findViewById(R.id.bankIv);
        atmIv = view.findViewById(R.id.atmIv);
        parkIv = view.findViewById(R.id.parkIv);
        mosqueIv = view.findViewById(R.id.mosqueIv);
        cafeIv = view.findViewById(R.id.cafeIv);
        educationIv = view.findViewById(R.id.educationIv);

    }

}
