package com.bitm.tourmate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.bitm.tourmate.DeveloperNProfile.DeveloperActivity;
import com.bitm.tourmate.DeveloperNProfile.ProfileActivity;
import com.bitm.tourmate.Model_Class.User;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class MainActivity extends AppCompatActivity {
    private String email,password;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private int check=0;
    String userId;
    String lastnameP,firstnamPe,emailP,pictureP;
    private FirebaseAuth firebaseAuth;
    private StorageReference storageReference;
    private DatabaseReference databaseReference;

    private ProgressDialog progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        email = getIntent().getStringExtra("email");
        password = getIntent().getStringExtra("password");
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        storageReference = FirebaseStorage.getInstance().getReference();

        FirebaseUser currentUser = firebaseAuth.getCurrentUser();
        userId = currentUser.getUid();

        //save();

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomnav);
        replaceFragment(new TripsFragment());
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                switch (menuItem.getItemId()) {

                    case R.id.nav_trips:
                        replaceFragment(new TripsFragment());
                        return true;

                    case R.id.nav_nearby:
                        replaceFragment(new NearbyFragment());
                        return true;


                    case R.id.nav_weather:
                        replaceFragment(new weatherFragment());
                        return true;


                }


                return false;
            }


        });


    }

    private void save() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage("Save Account?");
        builder.setPositiveButton("Always", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {



            }
        });
        builder.setNegativeButton("Never", null);

        AlertDialog alert = builder.create();
        alert.show();
    }



    public void replaceFragment(Fragment fragment) {

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.frameLayout,fragment);
        ft.commit();


    }
    public void shareFrance(String email,String password){
        sharedPreferences=getSharedPreferences("userInfo",MODE_PRIVATE);
        editor =sharedPreferences.edit();

        editor.putString("password",password);
        editor.putString("email",email);
        editor.apply();


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();

        menuInflater.inflate(R.menu.menus, menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {


        switch (item.getItemId()){

            case R.id.profile:

                passData();
              Intent intent= new Intent(MainActivity.this, ProfileActivity.class);
              intent.putExtra("first",firstnamPe);
              intent.putExtra("last",lastnameP);
              intent.putExtra("email",emailP);
              intent.putExtra("picture",pictureP);
              startActivity(intent);

                return true;

            case R.id.developer:
                startActivity(new Intent(this, DeveloperActivity.class));

                return true;

            case R.id.logOut:
                sharedPreferences=getSharedPreferences("userInfo",MODE_PRIVATE);
                editor =sharedPreferences.edit();

                editor.clear();
                editor.apply();
                Toast.makeText(this, "Remove account from this device", Toast.LENGTH_SHORT).show();
                 intent=new Intent(MainActivity.this,SignInActivity.class);
                startActivity(intent);
                finish();




                return true;
        }



        return super.onOptionsItemSelected(item);
    }

    private void passData() {


        final DatabaseReference dataRef = FirebaseDatabase.getInstance().getReference("users").child(userId);

        dataRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {

                    //for(DataSnapshot data: dataSnapshot.getChildren()) {

                    User user = dataSnapshot.getValue(User.class);



                   firstnamPe=user.getFirstName();
                    lastnameP=user.getLastName();
                    emailP=user.getEmail();
                    pictureP=user.getPicture();




                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }


        });
        //progress.dismiss();
    }

    private void setSharedPreferencesdata(){


    }



    public void delete() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setMessage("Remove amount from this device?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {



            }
        });
        builder.setNegativeButton("No", null);

        AlertDialog alert = builder.create();
        alert.show();


    }
/*
    @Override
    public void onBackPressed() {

        startActivity(new Intent(this,SignInActivity.class));
    }*/
}
